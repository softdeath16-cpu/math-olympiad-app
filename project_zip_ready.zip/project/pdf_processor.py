# PDF processing logic
