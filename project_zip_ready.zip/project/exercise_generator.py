# exercise generator logic
